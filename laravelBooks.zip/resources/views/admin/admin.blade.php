@extends('template.layout')

@section('content')
	<H1>ADMIN</H1>
@stop