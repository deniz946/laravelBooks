<div class="ui left demo vertical inverted sidebar labeled icon menu">
	<a class="item" href="{{ route('admin.roles.index') }}">
		<i class="home icon"></i>
		Roles
	</a>
	<a class="item" href="{{ route('admin.users.index') }}">
		<i class="user layout icon"></i>
		Users
	</a>

</div>