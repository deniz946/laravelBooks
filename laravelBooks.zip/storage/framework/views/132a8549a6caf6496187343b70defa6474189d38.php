<?php $__env->startSection('content'); ?>
	<?php /* NAV SIDEBAR */ ?>

	<div class="ui sidebar inverted vertical menu">
	   <a class="item">
	     1
	   </a>
	   <a class="item">
	     2
	   </a>
	   <a class="item">
	     3
	   </a>
	 </div>
	 <div class="pusher">
	   <!-- Site content !-->
	 </div>

	<?php /* <button type="button" class="btn btn-warning zzz">button</button> */ ?>
	<?php /* END SIDEBAR */ ?>

	<div class="panel panel-default">
		<div class="panel-body">
			<?php echo e($book->title); ?><br>
			<?php echo e($book->year); ?><br>
			<?php echo e($book->description); ?><br>
			<?php echo e($book->genre); ?><br>
			<?php echo e($book->author); ?><br>
			<img src="<?php echo e($book->img); ?>">
		</div>
	</div>

	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script type="text/javascript">
		$('.saltar').click(function(){
			$('.ui.modal').modal('show');
		});

		$('.zzz').click(function(){
			// $('.ui.sidebar')
			//   .sidebar('toggle')
			// ;

			$('.ui.modal')
			  .modal('show')
			;
		});




	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>