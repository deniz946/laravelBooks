 <?php $__env->startSection('content'); ?>
	<h2>create role</h2>
	<?php echo Form::open(array('route' => 'admin.roles.store', 'method' => 'POST', 'class' => 'ui form')); ?>

		<?php echo Form::label('name', null, ['class' => '']); ?>

		<?php echo Form::text('name', null , ['class' => 'ui input', 'placeholder' => 'Hola']); ?>

	<?php echo Form::close(); ?>

 <?php $__env->stopSection(); ?>	
	

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>