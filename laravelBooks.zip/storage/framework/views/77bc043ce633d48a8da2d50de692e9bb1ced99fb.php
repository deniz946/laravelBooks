<div class="ui huge menu">
  <a class="active item" href="/">
    Home
  </a>
  <a class="item">
    Messages
  </a>
  <a class="item">
    <form action='/' method='GET'>
      <div class="ui search">
      <div class="ui icon input">
        <input class="prompt" type="text" name='title' placeholder="Search book...">
        <i class="search icon"></i>
      </div>
      <div class="results"></div>
    </div>
    </form>
  </a>
  <div class="right menu">
    
    <?php if ( ! (Auth::check())): ?>
        <div class="item">
            <a href="/login"><div class="ui primary button">Login</div></a>
        </div>
    <?php endif; ?>
    <?php if(Auth::check()): ?>
    <?php if (\Entrust::hasRole('admin')) : ?>
      <div class="ui dropdown item sidebutton label"><img class="ui right spaced avatar image" src="<?php echo e(Auth::user()->img); ?>">Admin panel</div>
    <?php endif; // Entrust::hasRole ?>
    <div class="ui dropdown item">
      <?php echo e(Auth::user()->name); ?> <i class="dropdown icon"></i>
      <div class="menu">
        <a class="item" href="<?php echo e(route('users.profile')); ?>">Profile</a>
        <a href="/logout" class="item">Logout</a>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<br>


<?php $__env->startSection('js'); ?>

  <script>

  </script>

<?php $__env->stopSection(); ?>