<!DOCTYPE html>
<html lang="en" ng-app="app">
<head>
	<meta charset="UTF-8">
	<title>Books trading</title>
	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower/bootstrap/dist/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('plugins/bower/semantic/dist/semantic.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	 <base href="/">
</head>
<body>	

	<div>
		<div class="center-layout" >
			<header>
				<div class="nav">
					<?php echo $__env->make('template.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</header>
			<main>
				<div class="principal-content" id='main'>
					<?php echo $__env->make('template.index-sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					
					<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php echo $__env->yieldContent('content'); ?>
				</div>
			</main>

			<?php /* <footer class="page-footer">
				<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</footer> */ ?>

		</div></div>
		<script src="<?php echo e(asset('plugins/bower/jquery/dist/jquery.min.js')); ?>"></script>
		<?php /* <script src="<?php echo e(asset('plugins/bower/angular/angular.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/bower/angular-ui-router/release/angular-ui-router.min.js')); ?>"></script> */ ?>
		<script src="<?php echo e(asset('plugins/bower/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/bower/semantic/dist/semantic.js')); ?>"></script>
		<?php /* <script src="<?php echo e(asset('js/app.js')); ?>"></script> */ ?>

		<script type="text/javascript">

			$( document ).ready(function() {
			  $('.ui.dropdown').dropdown();

			  $('.sidebutton').click(function(){
			  	$('.ui.labeled.icon.sidebar').sidebar('toggle');
			  	$('body').addClass('sidebar_after_bg');
			  })


			});
			

			
		</script>
		
		<?php echo $__env->yieldContent('js'); ?>
			
</body>
</html>