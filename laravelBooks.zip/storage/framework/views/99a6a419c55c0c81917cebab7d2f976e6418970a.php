<?php $__env->startSection('content'); ?>

	<?php echo Form::open(['route' => ['admin.users.update', $user->id], 'method' => 'PUT', 'class' => 'ui form']); ?>

	  <div class="field">
	    <?php echo Form::label('name', null, ['class' => '']); ?>

	    <?php echo Form::text('name', $user->name , ['class' => 'ui input', 'placeholder' => 'Name']); ?>

	  </div>
	  <div class="field">
	    <?php echo Form::label('email', null, ['class' => '']); ?>

	    <?php echo Form::email('email', $user->email , ['class' => 'ui input', 'placeholder' => 'Your email']); ?>

	  </div>
	  <div class="form-group">
	  	<?php echo Form::label('password',null, ['class' => '']); ?>

	  	<?php echo Form::password('password', ['class' => 'ui input', 'placeholder' => '*********']); ?>

	  </div>
	 
	  <?php /* <div class="field">
	    <?php echo Form::label('role', null, ['class' => '']); ?>

	    <?php echo Form::select('role', $roles ); ?>

	  </div> */ ?>

	  <div class="field">
	  	<select name="role" id="input" class="form-control" required="required">
	  	<option selected="selected" value='<?php echo e($role_name[0]->id); ?>'><?php echo e($role_name[0]->display_name); ?></option>
	  		<?php foreach($roles as $role): ?>
	  			<option value='<?php echo e($role->id); ?>'><?php echo e($role->display_name); ?></option>
	  		<?php endforeach; ?>
	  	</select>
	  </div>

	  <div class="field">
	  	<?php echo Form::submit('edit user', ['class'=>'ui button']); ?>

	  </div>

	<?php echo Form::close(); ?>


	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>