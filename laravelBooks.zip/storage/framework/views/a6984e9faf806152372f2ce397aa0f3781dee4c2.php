<?php $__env->startSection('content'); ?>
<h2>Avaible roles</h2>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Create new role</h4>
			</div>
			<div class="modal-body">
				<?php echo Form::open(array('route' => 'admin.roles.store', 'method' => 'POST', 'class' => 'ui form')); ?>

				<div class="form-group">
					<?php echo Form::label('name', null, ['class' => '']); ?>

					<?php echo Form::text('name', null , ['class' => 'ui input', 'placeholder' => 'Roles name']); ?>

				</div>
				<div class="form-group">
					<?php echo Form::label('display_name', null, ['class' => '']); ?>

					<?php echo Form::text('display_name', null , ['class' => 'ui input', 'placeholder' => 'Display name']); ?>

				</div>
				<div class="form-group">
					<?php echo Form::label('description', null, ['class' => '']); ?>

					<?php echo Form::text('description', null , ['class' => 'ui input', 'placeholder' => 'Description']); ?>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<div class="ui buttons">
  <button class="ui red basic button" data-toggle="modal" data-target="#myModal">New role</button>
  <button class="ui blue basic button">New permission</button>
</div>
<table class="ui celled striped table">
	<thead>
		<tr><th colspan="3">
		Roles
		</th>
	</tr></thead>
	<tbody>
		<?php foreach($roles as $role): ?>
		<tr>
			<td class="collapsing">
				<i class="user icon"></i><a href=<?php echo e(route('admin.roles.show', $role->id)); ?>> <?php echo e($role->display_name); ?></a>
			</td>
			<td><?php echo e($role->description); ?></td>
			<td class="right aligned collapsing"><?php echo e($role->name); ?></td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$( document ).ready(function() {
		$('.modal-btn').click(function(){
			$('.ui.modal')
			.modal('show')
			;
		})
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>