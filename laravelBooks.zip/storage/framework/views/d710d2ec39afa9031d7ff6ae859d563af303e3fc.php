<?php $__env->startSection('content'); ?>

	<div class="ui grid container">

	<?php foreach($books as $book): ?>
	 <div class="four wide column stackable">
	 	<div class="ui special cards">
	 	  <div class="yellow card">
	 	    <div class="blurring dimmable image">
	 	      <div class="ui dimmer">

	 	        <div class="content">
	 	          <div class="center">
	 	            <a href="<?php echo e(route('books.show', $book->id)); ?>"><div class="ui inverted button">+info</div></a>
	 	          </div>
	 	        </div>

	 	      </div>
	 	      <img src="<?php echo e($book->img); ?>">
	 	    </div>
	 	    <div class="content">
		 	  <i class="right floated star icon"></i>
	 	      <a class="header"><?php echo e($book->title); ?></a>
	 	      <div class="meta">
	 	        <span class="date"><?php echo e($book->genre); ?></span>
	 	        <span class="date"><i><?php echo e($book->author); ?></i></span>
	 	      </div>
	 	    </div>
	 	    <div class="extra content">
	 	      <div class="author" align="center">
	 	            <img class="ui avatar image" src="<?php echo e($book->img); ?>"> <?php echo e($book->user->name); ?>

	 	          </div>
	 	    </div>

	 	  </div>
	 	</div>
	 </div>
	<?php endforeach; ?>
	</div><br>
	
	<center><?php echo e($books->render()); ?></center>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script type="text/javascript">
		$('.special.cards .image').dimmer({
		  on: 'hover'
		});
	</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>