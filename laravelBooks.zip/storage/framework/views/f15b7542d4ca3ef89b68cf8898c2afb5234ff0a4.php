<?php $__env->startSection('content'); ?>
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Create new permission</h4>
				</div>
				<div class="modal-body">
					<?php echo Form::open(array('route' => 'admin.permissions.store', 'method' => 'POST', 'class' => 'ui form')); ?>

					<div class="form-group">
						<?php echo Form::label('name', null, ['class' => '']); ?>

						<?php echo Form::text('name', null , ['class' => 'ui input', 'placeholder' => 'Roles name']); ?>

					</div>
					<div class="form-group">
						<?php echo Form::label('display_name', null, ['class' => '']); ?>

						<?php echo Form::text('display_name', null , ['class' => 'ui input', 'placeholder' => 'Display name']); ?>

					</div>
					<?php echo e(Form::hidden('id', $role->id)); ?>

					<div class="form-group">
						<?php echo Form::label('description', null, ['class' => '']); ?>

						<?php echo Form::text('description', null , ['class' => 'ui input', 'placeholder' => 'Description']); ?>

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>



	<h2><?php echo e($role->display_name); ?></h2>
	<div class="ui buttons">
	<a href="<?php echo e(route('admin.roles.index')); ?>"><button class="ui red basic button">Back to roles</button></a>
	<button class="ui blue basic button" data-toggle="modal" data-target="#myModal">New permission</button>
	</div>
	<table class="ui celled striped table">
		<thead>
			<tr><th colspan="3">
			Permissions
			</th>
		</tr></thead>
		<tbody>
			<?php foreach($permissions as $permission): ?>
			<tr>
				<td class="collapsing">
					<i class="user icon"></i><?php echo e($permission->id); ?>

				</td>
				<td><?php echo e($permission->display_name); ?></td>
				<td class="right aligned collapsing"><?php echo e($permission->name); ?></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>